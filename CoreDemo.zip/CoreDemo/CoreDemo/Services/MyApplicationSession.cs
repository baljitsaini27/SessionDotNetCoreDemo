﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreDemo.Services
{
    public class MyApplicationSession : IMyApplicationSession
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MyApplicationSession(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public string GetString(string Key)
        {
            return _httpContextAccessor.HttpContext.Session.GetString(Key);
        }

        public void SetString(string key, string value)
        {
            _httpContextAccessor.HttpContext.Session.SetString(key, value);
        }
    }
}
