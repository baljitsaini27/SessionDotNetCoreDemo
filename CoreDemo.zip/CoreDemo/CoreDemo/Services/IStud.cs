﻿using CoreDemo.Db_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreDemo.Services
{
    public interface IStud
    {
        List<Student> GetAllStudent(); 
        Student GetStudentByID(long Id);
    }
}
