﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CoreDemo.Db_Entities;
using Microsoft.EntityFrameworkCore;

namespace CoreDemo.Services
{
    public class Stud : IStud
    {
        private readonly BuyWiseDbContext _buyWiseDbContext;
        private readonly IMyApplicationSession _myApplicationSession;

        public Stud(BuyWiseDbContext buyWiseDbContext, IMyApplicationSession myApplicationSession)
        {
            _buyWiseDbContext = buyWiseDbContext;
            _myApplicationSession = myApplicationSession;
        }
        public List<Student> GetAllStudent()
        {
            var sessionname = _myApplicationSession.GetString("name");
            return _buyWiseDbContext.Student.ToList();
        }

        public Student GetStudentByID(long Id)
        { 
            Student objStudent;
            try
            {
                objStudent = _buyWiseDbContext.Student.FromSql("[DBO].[PROC_STUDENT_GETDETAIL_BYID] @Id",
                    new SqlParameter("@Id", Id)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                 return null;
            }

            return objStudent;
        }
    }
}
