﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreDemo.Services
{
    public interface IMyApplicationSession
    {
        void SetString(string key, string value);
        string GetString(string Key);
    }
}
