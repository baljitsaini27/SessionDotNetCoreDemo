﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CoreDemo.Models;
using CoreDemo.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
namespace CoreDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly IStud stud;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;
        public HomeController(IStud stud, IHostingEnvironment hostingEnvironment,IConfiguration configuration)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            this.stud = stud;
        }
        public IActionResult Index()
        {
            string constring = _configuration.GetConnectionString("DefaultConnection");
            string settings = _configuration.GetSection("abc").Value;
            string path1 = _hostingEnvironment.WebRootPath;
            string path2 = _hostingEnvironment.ContentRootPath;

            HttpContext.Session.SetString("name", "baljeet");
            var Students = stud.GetAllStudent();

            var StudentDetail = stud.GetStudentByID(11);
            return View();
        }

        public IActionResult About()
        {
            var name = HttpContext.Session.GetString("name");
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
